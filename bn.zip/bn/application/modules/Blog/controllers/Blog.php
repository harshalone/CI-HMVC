<?php

class Blog extends MY_Controller{
	
	function __construct(){
		parent:: __construct();
	}
	
	function index(){
		$data['content_view'] = 'blog/index_v';
		$this->template->core_template($data);
	}
	
	function view(){
		$data['content_view'] = 'blog/view_v';
		$this->template->core_template($data);
	}
}