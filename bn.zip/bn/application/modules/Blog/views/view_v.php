<div class="container">
    <div class="clearfix">&nbsp;</div>
 <div class="card mb-3">
  <div class="row no-gutters"> 
    <div class="col">
      <div class="card-body">
          <button type="button" class="btn btn-secondary float-right">
           <span class="badge badge-light">4</span> Subscribe
          </button>
        <h5 class="card-title">Juan Hernandez</h5>
        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
        <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
          
           
            <span class="iconify" data-icon="icomoon-free:facebook2" data-inline="false"></span>
            <span class="iconify" data-icon="zmdi:twitter-box" data-inline="false"></span>
            <span class="iconify" data-icon="fa:linkedin-square" data-inline="false"></span>
            <span class="iconify" data-icon="fa:youtube-square" data-inline="false"></span>
          
           
      </div>
    </div>
  </div>
</div>
<div class="card">
    <div class="card-header">
    <h1>Today we will get more than 1 Billion plastic bottles in the ocean</h1>
        <span class="iconify float-right" data-icon="subway:share" data-inline="false"></span>
  </div>
  <img src="https://via.placeholder.com/1280x720.png?text=Placeholder" class="card-img-top" alt="...">
  <div class="card-body">
    <p class="card-text">
    
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum. Praesent mauris. Fusce nec tellus sed augue semper porta. Mauris massa. <b>Lorem ipsum dolor sit amet, consectetur adipiscing elit</b>. Vestibulum lacinia arcu eget nulla. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. </p>

<p>Curabitur sodales ligula in libero. Sed dignissim lacinia nunc. Curabitur tortor. Pellentesque nibh. Aenean quam. In scelerisque sem at dolor. Maecenas mattis. Sed convallis tristique sem. Proin ut ligula vel nunc egestas porttitor. Morbi lectus risus, iaculis vel, suscipit quis, luctus non, massa. Fusce ac turpis quis ligula lacinia aliquet. </p>

<p>Mauris ipsum. <b>Curabitur sodales ligula in libero</b>. Nulla metus metus, ullamcorper vel, tincidunt sed, euismod in, nibh. Quisque volutpat condimentum velit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Nam nec ante. Sed lacinia, urna non tincidunt mattis, tortor neque adipiscing diam, a cursus ipsum ante quis turpis. Nulla facilisi. Ut fringilla. Suspendisse potenti. Nunc feugiat mi a tellus consequat imperdiet. Vestibulum sapien. Proin quam. </p>

<p>Etiam ultrices. Suspendisse in justo eu magna luctus suscipit. Sed lectus. Integer euismod lacus luctus magna. Quisque cursus, metus vitae pharetra auctor, sem massa mattis sem, at interdum magna augue eget diam. <b>Ut fringilla</b>. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Morbi lacinia molestie dui. Praesent blandit dolor. Sed non quam. In vel mi sit amet augue congue elementum. Morbi in ipsum sit amet pede facilisis laoreet. Donec lacus nunc, viverra nec, blandit vel, egestas et, augue. Vestibulum tincidunt malesuada tellus. </p>

<p>Ut ultrices ultrices enim. Curabitur sit amet mauris. Morbi in dui quis est pulvinar ullamcorper. Nulla facilisi. Integer lacinia sollicitudin massa. <b>Quisque cursus, metus vitae pharetra auctor, sem massa mattis sem, at interdum magna augue eget diam</b>. Cras metus. Sed aliquet risus a tortor. Integer id quam. Morbi mi. Quisque nisl felis, venenatis tristique, dignissim in, ultrices sit amet, augue. Proin sodales libero eget ante. </p>


        
        
    </p>
  </div>
</div>

<div class="clearfix">&nbsp;</div>
<div class="card border-left " >
  <div class="card-body">
    <span class="float-right">
        <a href="#" class="iconify" data-icon="ant-design:star-fill" data-inline="false"></a>
        <span class="iconify" data-icon="fa-solid:reply" data-inline="false"></span>
        <span class="iconify" data-icon="ant-design:like-fill" data-inline="false"></span>
        <span class="iconify" data-icon="ant-design:flag-fill" data-inline="false"></span>
      </span>  
    <h5 class="card-title">Nikola Tesla <small class="text-muted">21 minutes ago 
        <span class="badge badge-secondary">0 points</span>
            </small></h5>
      
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> 
  </div>
</div>
<div class="clearfix">&nbsp;</div>
<div class="card border-left " >
  <div class="card-body">
      <form>
      <div class="form-group">
    <label for="exampleFormControlTextarea1">Bill Gates</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
          <div class="clearfix">&nbsp;</div>
          <button type="button" class="btn btn-dark float-right">Add Comment</button>
  </div>
</form>
  </div>
</div>

<div class="clearfix">&nbsp;</div>
</div>

