<div class="container">

    <div class="clearfix">&nbsp;</div>
    <div class="card">
        <div class="card-body">

            <div class="row">
                <div class="col-8">


                    <div class="row">
                        <div class="col-sm-6">
                            <div class="card">
                                <img src="https://dummyimage.com/400x200/000000/fafaff.png&text=Developers" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title">DevOps and Agile: A Perfect Combination</h5>
                                    <p class="card-text">DevOps and Agile Enterprises are now getting digitally transformed by adopting emerging technologies with new tools and techniques.</p>

                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="card">
                                <img src="https://dummyimage.com/400x200/000000/fafaff.png&text=Agile" class="card-img-top" alt="...">
                                <div class="card-body">
                                    <h5 class="card-title">The Guide to Workplace Communication Channels</h5>
                                    <p class="card-text">What channels do you use? Emails and IMs and shared docs – oh my! With all the different communication channels we use every day at work, it’s easy to miss their nuances. </p>

                                </div>
                            </div>
                        </div>
                    </div>


                </div>

                <div class="col-4">

                    <div class="list-group">
                        <a href="#" class="list-group-item list-group-item-action">
                            <div class="d-flex w-100 justify-content-between">
                                <img src="https://dummyimage.com/80x80/344ecf/fff.png&text=Tech" alt="..." class="float-left mr-2">
                                <h5 class="mb-1">TechTalks With Tom Smith: Using Machine Learning in Software Development — Keys to Success
                            </div>
                        </a>
                        <a href="#" class="list-group-item list-group-item-action">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1">Testing PostgreSQL Compatibility in Yugabyte DB 2.0</h5>
                            </div>
                        </a>
                        <a href="#" class="list-group-item list-group-item-action">
                            <div class="d-flex w-100 justify-content-between">
                                <img src="https://dummyimage.com/80x80/344ecf/fff.png&text=Talk" alt="..." class="float-left mr-2">
                                <h5 class="mb-1">Growing an Engineering Team From 0 to 120 </h5>
                            </div>
                            <p class="mb-1">Matias di Tada is the VP of Product Engineering at Avature, an innovative company building platforms for strategic HR. He started there as a software developer in 2007 and worked his way up.</p>

                        </a>
                    </div>


                </div>
            </div>

        </div>
    </div>

    <div class="clearfix">&nbsp;</div>


    <div class="card-group">
        <div class="card">
            <img src="https://dummyimage.com/400x200/000000/fafaff.png&text=Google" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">Last updated 3 mins ago</small>
            </div>
        </div>
        <div class="card">
            <img src="https://dummyimage.com/400x200/000000/fafaff.png&text=eCommerse" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">Last updated 3 mins ago</small>
            </div>
        </div>
        <div class="card">
            <img src="https://dummyimage.com/400x200/000000/fafaff.png&text=Dev" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">Last updated 3 mins ago</small>
            </div>
        </div>

        <div class="card">
            <img src="https://dummyimage.com/400x200/000000/fafaff.png&text=Tech" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Card title</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">Last updated 3 mins ago</small>
            </div>
        </div>




        <div class="clearfix">&nbsp;</div>


    </div>
    <div class="clearfix">&nbsp;</div>