<div class="container">
    <div class="clearfix">&nbsp;</div>

    <div class="row">
        <div class="col">

            <div class="card">
                <div class="card-body">



                    <form>
                        <div class="form-group">
                            <label for="exampleFormControlInput1">Subject:</label>
                            <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Re: new article...">
                        </div>
                         
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Message:</label>
                            <textarea class="form-control" id="exampleFormControlTextarea1" rows="8"></textarea>
                        </div>
                        <div class="clearfix">&nbsp;</div>
                        <button type="button" class="btn btn-secondary btn-md btn-block">Preview</button>
                    </form>



                </div>
            </div>


        </div> 
    </div>

    <div class="clearfix">&nbsp;</div>
</div>