<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Trumbowyg/2.19.1/ui/trumbowyg.min.css" integrity="sha256-iS3knajmo8cvwnS0yrVDpNnCboUEwZMJ6mVBEW1VcSA=" crossorigin="anonymous" />
<div class="container">
    <div class="clearfix">&nbsp;</div>
    <div class="card">
        <div class="card-body">

            <form>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Title</label>
                    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="7 Billion People on this earth...">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Meta Keywords</label>
                    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="keyword 1, keyword 2 etc.">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Meta Description</label>
                    <textarea class="form-control" placeholder="This meta description will be shown on Google search results" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Header Image Url</label>
                    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="vgy.me/imagwefsaf.png">
                </div>


                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Article</label>
                    <textarea class="form-control" id="wysiwyg" rows="10"></textarea>
                </div>
                <button type="button" class="btn btn-secondary btn-md btn-block">Submit</button>
            </form>
        </div>
    </div>

    <div class="clearfix">&nbsp;</div>
</div>
