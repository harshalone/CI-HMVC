<div class="container">
    <div class="clearfix">&nbsp;</div>
    <div class="card">
        <div class="card-body">

            <form>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Title</label>
                    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Meta Keywords</label>
                    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="keyword 1, keyword 2 etc.">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Meta Description</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="exampleFormControlInput1">Image Url</label>
                    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="vgy.me/imagwefsaf.png">
                </div>


                <div class="form-group">
                    <label for="exampleFormControlTextarea1">Article</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="10"></textarea>
                </div>
                <button type="button" class="btn btn-secondary btn-md btn-block">Submit</button>
            </form>
        </div>
    </div>

    <div class="clearfix">&nbsp;</div>
</div>