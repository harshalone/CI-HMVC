<div class="container">
    <div class="clearfix">&nbsp;</div>
<table class="table table-hover table-light">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Handle</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>Otto</td>
        </tr>
        <tr>
            <th scope="row">2</th>
            <td>Jacob</td>
            <td>Thornton</td>
        </tr>
        <tr>
            <th scope="row">3</th>
            <td>@twitter</td>
            <td>@twitter</td>
        </tr>
    </tbody>
</table>
    
    <div class="clearfix">&nbsp;</div>
</div>