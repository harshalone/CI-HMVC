<div class="container min-vh-100">
    <div class="clearfix">&nbsp;</div>
    <div class="card-group">
        <div class="card">

            <div class="card-body">
                <h5 class="card-title">Articles</h5>
                <h1>24</h1>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
            </div>
        </div>
        <div class="card">

            <div class="card-body">
                <h5 class="card-title">Subscribers</h5>
                <h1>24</h1>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Comments</h5>
               <h1>24</h1>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
            </div>
        </div>
    </div>
    <div class="clearfix">&nbsp;</div>

    <table class="table table-hover table-light">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row">1</th>
                <td>The Guide to Workplace Communication Channels You Didn’t Know You Needed </td>
                <td>
                    <a class="btn btn-outline-light btn-sm">
                        <span class="iconify" data-icon="ls:view" data-inline="true"></span>
                    </a>
                    <a class="btn btn-outline-light btn-sm">
                        <span class="iconify" data-icon="raphael:edit" data-inline="true"></span>
                    </a>
                    <a class="btn btn-outline-light btn-sm">
                        <span class="iconify" data-icon="ic:round-delete-forever" data-inline="true"></span>
                    </a>
                </td>
            </tr>
            <tr>
                <th scope="row">2</th>
                <td>DevOps and Agile: A Perfect Combination </td>
                <td>
                    <a class="btn btn-outline-light btn-sm">
                        <span class="iconify" data-icon="ls:view" data-inline="true"></span>
                    </a>
                    <a class="btn btn-outline-light btn-sm">
                        <span class="iconify" data-icon="raphael:edit" data-inline="true"></span>
                    </a>
                    <a class="btn btn-outline-light btn-sm">
                        <span class="iconify" data-icon="ic:round-delete-forever" data-inline="true"></span>
                    </a>
                </td>
            </tr>
            <tr>
                <th scope="row">3</th>
                <td>A Pattern for Using Agile Patterns</td>
                <td>
                    <a class="btn btn-outline-light btn-sm">
                        <span class="iconify" data-icon="ls:view" data-inline="true"></span>
                    </a>
                    <a class="btn btn-outline-light btn-sm">
                        <span class="iconify" data-icon="raphael:edit" data-inline="true"></span>
                    </a>
                    <a class="btn btn-outline-light btn-sm">
                        <span class="iconify" data-icon="ic:round-delete-forever" data-inline="true"></span>
                    </a>
                </td>
            </tr>
        </tbody>
    </table>

</div>