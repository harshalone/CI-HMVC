<div class="container min-vh-100">
  <div class="clearfix">&nbsp;</div>
    <div class="card-group">
  <div class="card">
     
    <div class="card-body">
      <h5 class="card-title">Articles</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
  <div class="card">
    
    <div class="card-body">
      <h5 class="card-title">Subscribers</h5>
      <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
  <div class="card"> 
    <div class="card-body">
      <h5 class="card-title">Comments</h5>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </div>
</div>
 <div class="clearfix">&nbsp;</div>   
  
<table class="table table-hover table-light">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Title</th> 
      <th scope="col">Handle</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td> 
    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td> 
    </tr>
    <tr>
      <th scope="row">3</th> 
      <td>@twitter</td>
        <td>@twitter</td>
    </tr>
  </tbody>
</table> 
    
</div>
 