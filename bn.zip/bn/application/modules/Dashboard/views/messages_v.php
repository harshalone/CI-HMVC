<div class="container">
    <div class="clearfix">&nbsp;</div>
    <div class="card">
        <div class="card-body">

            <div class="row">
                <div class="col-4 overflow-auto" style="height: 600px;">
                    <ul class="list-group list-group-flush">
                      <li class="list-group-item">Cras justo odio</li>
                      <li class="list-group-item">Dapibus ac facilisis in</li>
                      <li class="list-group-item">Morbi leo risus</li>
                      <li class="list-group-item">Porta ac consectetur ac</li>
                      <li class="list-group-item">Vestibulum at eros</li>
                        
                        <li class="list-group-item">Cras justo odio</li>
                      <li class="list-group-item">Dapibus ac facilisis in</li>
                      <li class="list-group-item">Morbi leo risus</li>
                      <li class="list-group-item">Porta ac consectetur ac</li>
                      <li class="list-group-item">Vestibulum at eros</li>
                        
                        <li class="list-group-item">Cras justo odio</li>
                      <li class="list-group-item">Dapibus ac facilisis in</li>
                      <li class="list-group-item">Morbi leo risus</li>
                      <li class="list-group-item">Porta ac consectetur ac</li>
                      <li class="list-group-item">Vestibulum at eros</li>
                        
                        <li class="list-group-item">Cras justo odio</li>
                      <li class="list-group-item">Dapibus ac facilisis in</li>
                      <li class="list-group-item">Morbi leo risus</li>
                      <li class="list-group-item">Porta ac consectetur ac</li>
                      <li class="list-group-item">Vestibulum at eros</li>
                    </ul>
                    
                    
                    
                </div>
                <div class="col-8 overflow-auto" style="height: 600px;">
                      
                    <div class="card mr-2">
                      <div class="card-body">
                        This is some text within a card body.
                      </div>
                    </div>
                    <div class="clearfix">&nbsp;</div> 
                    <div class="card mr-2">
                      <div class="card-body">
                        This is some text within a card body.
                      </div>
                    </div>
                    <div class="clearfix">&nbsp;</div>
                     <div class="card mr-2">
                      <div class="card-body">
                        This is some text within a card body.
                      </div>
                    </div>
                    <div class="clearfix">&nbsp;</div>
                     <div class="card mr-2">
                      <div class="card-body">
                        This is some text within a card body.
                      </div>
                    </div>
                    <div class="clearfix">&nbsp;</div>
                     <div class="card mr-2">
                      <div class="card-body">
                        This is some text within a card body.
                      </div>
                    </div>
                    <div class="clearfix">&nbsp;</div>
                     <div class="card mr-2">
                      <div class="card-body">
                        This is some text within a card body.
                      </div>
                    </div>
                    <div class="clearfix">&nbsp;</div>
                 
                    
                    
                <hr/>  
                    <div class="form-group">
                    <label for="exampleFormControlTextarea1">Nikola Tesla</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                     <div class="clearfix">&nbsp;</div>   
                        <button type="button" class="btn btn-dark float-right">Send</button>
                        <div class="clearfix">&nbsp;</div>
                  </div>
                  
                    
                    
                </div>
            </div>

        </div>
    </div>
    <div class="clearfix">&nbsp;</div>
</div>