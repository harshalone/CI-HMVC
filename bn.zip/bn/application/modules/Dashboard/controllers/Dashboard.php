<?php

class Dashboard extends MY_Controller{
	
	function __construct(){
		parent:: __construct();
	}
	
	function index(){
		$data['content_view'] = 'dashboard/index_v';
		$this->template->dashboard_template($data);
	}
    
    function add_article(){
		$data['content_view'] = 'dashboard/add_article_v';
		$this->template->dashboard_template($data);
	}
    
    function subscribers(){
		$data['content_view'] = 'dashboard/subscribers_v';
		$this->template->dashboard_template($data);
	}
    
    function messages(){
		$data['content_view'] = 'dashboard/messages_v';
		$this->template->dashboard_template($data);
	}
    
    function send_email(){
		$data['content_view'] = 'dashboard/send_email_v';
		$this->template->dashboard_template($data);
	}
	 
}