<?php

class Auth extends MY_Controller{
	
	function __construct(){
		parent:: __construct();
	}
	
	function login(){
		$data['content_view'] = 'auth/login_v';
		$this->template->core_template($data);
	}
	
	function signup(){
		$data['content_view'] = 'auth/signup_v';
		$this->template->core_template($data);
	}
    
    function recover(){
		$data['content_view'] = 'auth/recover_v';
		$this->template->core_template($data);
	}
}