
    <div class="container">
      <header class="blog-header py-3">
        <div class="row flex-nowrap justify-content-between align-items-center">
          <div class="col-4 pt-1">
            <a class="h4 text-muted" href="<?php echo site_url('/home'); ?>">Logo</a>
          </div>
          <div class="col-4 text-center">
             
          </div>
          <div class="col-4 d-flex justify-content-end align-items-center">
           
            <a class="btn btn-sm btn-outline-secondary ml-2" href="<?php echo site_url('auth/signup'); ?>">Sign Out</a>
          </div>
        </div>
      </header>
    </div>