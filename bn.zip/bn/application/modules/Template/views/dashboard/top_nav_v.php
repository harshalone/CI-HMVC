
	
	<div class="border-bottom"></div>
	<div class="container ">
	
      <div class="nav-scroller py-1">
        <nav class="nav d-flex justify-content-between">
          <a class="p-2 text-muted text-decoration-none" href="<?php echo site_url('dashboard'); ?>"><span class="iconify" data-icon="ic:round-dashboard" data-inline="true"></span> Dashboard</a>
          <a class="p-2 text-muted text-decoration-none" href="<?php echo site_url('dashboard/add_article'); ?>">
            <span class="iconify" data-icon="gridicons:add" data-inline="true"></span>
              Add Article
            </a>
          <a class="p-2 text-muted text-decoration-none" href="<?php echo site_url('dashboard/subscribers'); ?>">
             <span class="iconify" data-icon="simple-line-icons:user-following" data-inline="true"></span> 
              Subscribers</a>
          <a class="p-2 text-muted text-decoration-none" href="<?php echo site_url('dashboard/messages'); ?>">
              <span class="iconify" data-icon="ant-design:message-fill" data-inline="true"></span> 
              Message</a>
          <a class="p-2 text-muted text-decoration-none" href="<?php echo site_url('dashboard/send_email'); ?>">
              <span class="iconify" data-icon="mdi:email-send" data-inline="true"></span>
              Send Email</a>
           
        </nav>
      </div>
    </div>
	
	<div class="border-bottom"></div>