
	
	<div class="border-bottom"></div>
	<div class="container ">
	
      <div class="nav-scroller py-1">
        <nav class="nav d-flex justify-content-between">
          <a class="p-2 text-muted text-decoration-none" href="#">World</a>
          <a class="p-2 text-muted text-decoration-none" href="#">U.S.</a>
          <a class="p-2 text-muted text-decoration-none" href="#">Technology</a>
          <a class="p-2 text-muted text-decoration-none" href="#">Design</a>
          <a class="p-2 text-muted text-decoration-none" href="#">Culture</a>
          <a class="p-2 text-muted text-decoration-none" href="#">Business</a>
          <a class="p-2 text-muted text-decoration-none" href="#">Politics</a>
          <a class="p-2 text-muted text-decoration-none" href="#">Opinion</a>
          <a class="p-2 text-muted text-decoration-none" href="#">Science</a>
          <a class="p-2 text-muted text-decoration-none" href="#">Health</a>
          <a class="p-2 text-muted text-decoration-none" href="#">Style</a>
		  <a class="p-2 dropdown-toggle text-decoration-none" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Dropdown</a>
			<div class="dropdown-menu">
			  <a class="dropdown-item" href="#">Action</a>
			  <a class="dropdown-item" href="#">Another action</a>
			  <a class="dropdown-item" href="#">Something else here</a>
			  <div class="dropdown-divider"></div>
			  <a class="dropdown-item" href="#">Separated link</a>
			</div>
        </nav>
      </div>
    </div>
	
	<div class="border-bottom"></div>