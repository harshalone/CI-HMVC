<?php

class Template extends MY_Controller{
	
	function __construct(){
		parent:: __construct();
	}
	
	function core_template($data = NULL){
		
		$this->load->view('Template/core_template_v', $data);
		
	}
    
    function admin_template($data = NULL){
		
		$this->load->view('Template/admin_template_v', $data);
		
	}
    
    function dashboard_template($data = NULL){
		
		$this->load->view('Template/dashboard_template_v', $data);
		
	}
}