<?php

class Users extends MY_Controller{
	
	function __construct(){
		parent:: __construct();
	}
	
	function index(){
		$data['content_view'] = 'admin/users/index_v';
		$this->template->admin_template($data);
	}
	 
}